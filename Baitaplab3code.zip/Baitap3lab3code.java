package exanle;
import java.until.Scanner;
public class Test {
Pulic static void main(String[] args){
		Scandent[]clst = new Student[N];
for (Student s: cls){
	String name = Scanner.next();
	int year = scanner.nextlnt();
}
int total = 0;
System.out.println(x: "Danh sach lop: ");
for (int i=0; i<N; ==i){
    total += 2022-cls[i].getYear();
	System.out.println(x:cls(i).getName());
}
System.out.println("Tong so tuoi:" + total);
}
}